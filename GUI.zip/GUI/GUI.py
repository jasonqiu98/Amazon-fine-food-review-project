
import tkinter as tk
from PIL import Image, ImageTk

window = tk.Tk()
window.title('Result Display')
window.geometry('600x650')


im1 = Image.open('naivebayes.png')
imm1 = im1.resize((350,350))
img1 = ImageTk.PhotoImage(imm1)

im11 = Image.open('nb-1.png')
nb = ImageTk.PhotoImage(im11.resize((350,150)))

im2 = Image.open('svm.png')
imm2 = im2.resize((350,350))
img2 = ImageTk.PhotoImage(imm2)

im22 = Image.open('svm-1.png')
svm = ImageTk.PhotoImage(im22.resize((350,150)))

im3 = Image.open('knn.png')
imm3 = im3.resize((350,350))
img3 = ImageTk.PhotoImage(imm3)

im33 = Image.open('knn-1.png')
knn = ImageTk.PhotoImage(im33.resize((350,150)))

wc1 = Image.open('c1.png')
wc1 = ImageTk.PhotoImage(wc1.resize((350,350)))

wc2 = Image.open('c2.png')
wc2 = ImageTk.PhotoImage(wc2.resize((350,350)))

bg = Image.open('bg.png')
bg = ImageTk.PhotoImage(bg.resize((350,150)))

# var = tk.StringVar()
label = tk.Label(window,width=50, height=2,text='')
label.place(x=170,y=580)

def change_photo1():
    label1 = tk.Label(window,image=img1)
    label1.place(x=170,y=20)
    l = tk.Label(window,image=nb)
    l.place(x=170,y=400)
    label.config(text='Model Evauation (with TPR=0.714)')

def change_photo2():
    label2 = tk.Label(window,image=img2)
    label2.place(x=170,y=20)
    l = tk.Label(window,image=svm)
    l.place(x=170,y=400)
    label.config(text='Model Evauation (with TPR=0.767, ROC AUC Score : 0.952)')

def change_photo3():
    label2 = tk.Label(window,image=img3)
    label2.place(x=170,y=20)
    l = tk.Label(window,image=knn)
    l.place(x=170,y=400)
    label.config(text='Model Evauation (with TPR=0.922)')

def change_photo4():
    label3 = tk.Label(window,image=wc1)
    label3.place(x=170,y=20)
    l = tk.Label(window,image=bg)
    l.place(x=170,y=400)
    label.config(text='Word Cloud Concerning Review Summary')

def change_photo5():
    label4 = tk.Label(window,image=wc2)
    label4.place(x=170,y=20)
    l = tk.Label(window,image=bg)
    l.place(x=170,y=400)
    label.config(text='Word Cloud Concerning Review Text')

b1 = tk.Button(window,width=16,height=2,text='Naive Bayes',command=change_photo1)
b1.place(x=10,y=20)
b2 = tk.Button(window,width=16,height=2,text='SVM',command=change_photo2)
b2.place(x=10,y=100)
b3 = tk.Button(window,width=16,height=2,text='KNN',command=change_photo3)
b3.place(x=10,y=180)
b4 = tk.Button(window,width=16,height=2,text='Word Cloud1',command=change_photo4)
b4.place(x=10,y=260)
b5 = tk.Button(window,width=16,height=2,text='Word Cloud2',command=change_photo5)
b5.place(x=10,y=340)
window.mainloop()

